from qgis.core import (
    Qgis,
    QgsProject,
    QgsVectorLayer,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsWkbTypes,
    QgsField,
    QgsUnitTypes,
    QgsFeatureRequest,
    QgsCoordinateTransform
)
from qgis.PyQt.QtCore import (
    Qt,
    QVariant
)
from qgis.PyQt.QtWidgets import (
    QAction,
    QDialog,
    QVBoxLayout,
    QFormLayout,
    QHBoxLayout,
    QSpinBox,
    QDoubleSpinBox,
    QDialogButtonBox,
    QLabel,
    QWidget,
    QSizePolicy
)
from qgis.PyQt.QtGui import (
    QIcon
)
from qgis.gui import (
    QgsMapTool,
    QgsRubberBand,
    QgsProjectionSelectionWidget,
    QgsSnapIndicator
)

import math
import os


class TrialConfigDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Trial Configuration")
        self.setMinimumWidth(300)
        self.setLayout(QVBoxLayout())

        self.iface = iface
        self.canvas = self.iface.mapCanvas()

        form_layout = QFormLayout()
        form_layout.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)

        def create_row_widget(input_widget, tooltip_text):
            container = QWidget()
            layout = QHBoxLayout(container)
            layout.setContentsMargins(0, 0, 0, 0)
            layout.setSpacing(6)

            input_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)

            info_lbl = QLabel("🛈")
            info_lbl.setToolTip(tooltip_text)
            info_lbl.setStyleSheet("color: #0078d7;")
            info_lbl.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

            layout.addWidget(input_widget, 1)
            layout.addWidget(info_lbl, 0)

            container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            return container


        # CRS safety stuff
        map_crs = self.canvas.mapSettings().destinationCrs()

        self.lbl_map_crs = QLabel()
        self.lbl_map_crs.setWordWrap(True)

        self.crs_out = QgsProjectionSelectionWidget()
        self.crs_out.setCrs(map_crs) # default poly CRS = map CRS

        form_layout.addRow(
            "Map CRS:",
            create_row_widget(
                self.lbl_map_crs,
                "The coordinate reference system of your project/map. This MUST be a projected reference system that uses metres as distance units."
            )
        )
        form_layout.addRow(
            "Trial CRS:",
            create_row_widget(
                self.crs_out,
                "The coordinate reference system for the output trial. This may be the CRS required by the farm business."
            )
        )

        self.crs_out.crsChanged.connect(self._update_crs_display)
        self._update_crs_display()

        # Inputs
        self.spin_n = QSpinBox()
        self.spin_n.setRange(1, 100)
        self.spin_n.setValue(4)

        self.spin_width = QDoubleSpinBox()
        self.spin_width.setRange(0.1, 1000.0)
        self.spin_width.setValue(12.0) # Default strip width
        self.spin_width.setSuffix(" m")

        self.spin_length = QDoubleSpinBox()
        self.spin_length.setRange(1.0, 10000.0)
        self.spin_length.setValue(100.0) # Default trial length
        self.spin_length.setSuffix(" m")

        # Live Feedback Labels
        self.lbl_total_width = QLabel("0 m")
        self.lbl_total_area = QLabel("0 ha")

        form_layout.addRow(
            "Strip Count:",
            create_row_widget(
                self.spin_n,
                "The total number of strips in the trial (For example: No. Replicates * No. Treatments)"
            )
        )
        form_layout.addRow(
            "Strip Width:",
            create_row_widget(
                self.spin_width,
                "Width of a single strip. Usually equal to the width of the harvester or sprayer bar."
            )
        )
        form_layout.addRow(
            "Trial Length:",
            create_row_widget(
                self.spin_length,
                "Total length of the trial."
            )
        )
        form_layout.addRow(
            "Trial Width:",
            create_row_widget(
                self.lbl_total_width,
                "Calculated width of the full trial."
            )
        )
        form_layout.addRow(
            "Trial Area:",
            create_row_widget(
                self.lbl_total_area,
                "Calculated area of the full trial."
            )
        )

        self.layout().addLayout(form_layout)

        # Buttons
        self.btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.btns.accepted.connect(self.accept)
        self.btns.rejected.connect(self.reject)
        self.layout().addWidget(self.btns)

        self.btn_ok = self.btns.button(QDialogButtonBox.Ok)

        # Connect signals for live updates
        self.spin_n.valueChanged.connect(self.update_totals)
        self.spin_width.valueChanged.connect(self.update_totals)
        self.spin_length.valueChanged.connect(self.update_totals)

        self.update_totals()


    # Show warnings if CRS is not in metres
    def _is_metre_crs(self, crs) -> bool:
        return crs.mapUnits() == QgsUnitTypes.DistanceMeters


    def _paint_crs_widget(self, widget, ok: bool, tooltip: str):
        if ok:
            widget.setStyleSheet("")
            widget.setToolTip("")
        else:
            widget.setStyleSheet("color:#b00020; font-weight:600;")
            widget.setToolTip(tooltip)


    def accept(self):
        map_crs = self.canvas.mapSettings().destinationCrs()
        if not self._is_metre_crs(map_crs):
            self.iface.messageBar().pushMessage(
                "Invalid Project CRS",
                "Set the project/map CRS to a projected CRS in metres (e.g. UTM) before creating strips.",
                level=Qgis.Warning,
                duration=6
            )
            return
        super().accept()


    def _update_crs_display(self):
        map_crs = self.canvas.mapSettings().destinationCrs()
        out_crs = self.crs_out.crs()

        def crs_text(crs):
            return f"{crs.authid()} — {crs.description()}"

        warn = "Project/Map CRS must be a projected CRS in metres (e.g. UTM)."

        self.lbl_map_crs.setText(crs_text(map_crs))

        map_ok = self._is_metre_crs(map_crs)

        # Paint ONLY the Map CRS label (Trial CRS must never go red)
        self._paint_crs_widget(self.lbl_map_crs, map_ok, warn)

        # Never show Trial CRS in red; you can still provide a tooltip if you want
        self.crs_out.setStyleSheet("")
        self.crs_out.setToolTip("Output layer will be created in this CRS.")

        # OK button gating + styling
        if hasattr(self, "btn_ok") and self.btn_ok is not None:
            self.btn_ok.setEnabled(map_ok)

            if map_ok:
                self.btn_ok.setStyleSheet("")
                self.btn_ok.setToolTip("")
            else:
                # Greyed out (disabled) but with a red border highlight
                self.btn_ok.setStyleSheet("""
                    QPushButton:disabled {
                        border: 2px solid #b00020;
                        background-color: #eeeeee;
                        color: #777777;
                        padding: 6px 12px;
                    }
                """)
                self.btn_ok.setToolTip(warn)


    def update_totals(self):
        n = self.spin_n.value()
        w = self.spin_width.value()
        l = self.spin_length.value()

        tot_w = n * w
        area_sqm = tot_w * l
        area_ha = area_sqm / 10000.0

        self.lbl_total_width.setText(f"{tot_w:.2f} m")
        self.lbl_total_area.setText(f"{area_ha:.4f} ha")


    def get_params(self):
        return (
            self.spin_n.value(),
            self.spin_width.value(),
            self.spin_length.value(),
            self.crs_out.crs()
        )


class PaddockPlacementTool(QgsMapTool):
    def __init__(self, iface, n, width, length, out_crs):
        self.iface = iface
        self.canvas = self.iface.mapCanvas()
        super().__init__(self.canvas)

        self.n = n
        self.width = width
        self.length = length
        self.out_crs = out_crs

        # CRS
        self.map_crs = self.canvas.mapSettings().destinationCrs()
        ctx = QgsProject.instance().transformContext()
        self._map_to_out = QgsCoordinateTransform(self.map_crs, self.out_crs, ctx)

        # Selection / direction state
        self.line_selected = False
        self.line_layer = None
        self.line_geom = None
        self.line_crs = None

        self.ref_origin_map = None

        self.segment_angle = None
        self.virtual_x_map = None

        # Visuals
        self.rubber_band = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rubber_band.setColor(Qt.red)
        self.rubber_band.setWidth(2)
        self.rubber_band.setFillColor(Qt.transparent)
        self.rubber_band.reset(QgsWkbTypes.PolygonGeometry)  # no preview until first click

        self.snap_indicator = QgsSnapIndicator(self.canvas)

    def deactivate(self):
        self._cleanup()
        super().deactivate()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.cancel()
            event.accept()
            return
        super().keyPressEvent(event)

    def canvasReleaseEvent(self, event):
        if event.button() == Qt.RightButton:
            self.cancel()
            return
        if event.button() != Qt.LeftButton:
            return


        clicked_map, match = self.snap_from_event_with_indicator(event)

        # 1st click: select line (or fallback vertical at this location). Show preview only after this.
        if not self.line_selected:
            self._select_line_or_vertical(clicked_map, match)
            self.line_selected = True

            self.iface.messageBar().pushMessage(
                "Direction set",
                "Move mouse to position the edge midpoint and choose side, then click to place.",
                level=Qgis.Info,
                duration=5
            )

            mid_map, side_sign = self._midpoint_and_side_from_map_point(clicked_map)
            if side_sign is None:
                side_sign = +1
            self.update_rubber_band(mid_map, self.segment_angle, side_sign)
            return

        # 2nd click: chooses midpoint (projected onto chosen/virtual line) and side, then builds strips
        mid_map, side_sign = self._midpoint_and_side_from_map_point(clicked_map)
        if side_sign is None:
            self.iface.messageBar().pushMessage(
                "Side not set",
                "Click clearly to one side of the line/direction to choose the trial side.",
                level=Qgis.Warning,
                duration=3
            )
            return

        self.create_features(mid_map, self.segment_angle, side_sign)
        self.cancel()

    def canvasMoveEvent(self, event):
        # Always update the normal QGIS snap indicator while hovering
        hovered_map, _match = self.snap_from_event_with_indicator(event)

        # Preview only after first click (as requested)
        if not self.line_selected or self.segment_angle is None:
            return

        mid_map, side_sign = self._midpoint_and_side_from_map_point(hovered_map)
        if side_sign is None:
            side_sign = +1

        self.update_rubber_band(mid_map, self.segment_angle, side_sign)

    def cancel(self):
        self.line_selected = False
        self.line_layer = None
        self.line_geom = None
        self.line_crs = None
        self.segment_angle = None
        self.virtual_x_map = None
        self.ref_origin_map = None
        self._cleanup()
        self.canvas.unsetMapTool(self)

    def _cleanup(self):
        self.rubber_band.reset(QgsWkbTypes.PolygonGeometry)
        self.snap_indicator.setVisible(False)

    def calculate_azimuth(self, p1, p2):
        # radians relative to North
        return math.atan2(p2.x() - p1.x(), p2.y() - p1.y())

    def snap_from_event_with_indicator(self, event):
        match = self.canvas.snappingUtils().snapToMap(event.pos())

        self.snap_indicator.setMatch(match)
        self.snap_indicator.setVisible(match.isValid())

        if match.isValid():
            return match.point(), match
        return event.mapPoint(), match


    def _select_line_or_vertical(self, clicked_map: QgsPointXY, match):
        # Fallback: vertical at click location in MAP CRS
        if (not match.isValid()
            or match.layer() is None
            or not isinstance(match.layer(), QgsVectorLayer)):
            self.virtual_x_map = clicked_map.x()
            self.ref_origin_map = clicked_map
            self.line_layer = None
            self.line_geom = None
            self.line_crs = None
            self.segment_angle = 0.0
            return

        layer = match.layer()

        # Only meaningful for line/polygon geometries
        gtype = QgsWkbTypes.geometryType(layer.wkbType())
        if gtype == QgsWkbTypes.PointGeometry:
            self.virtual_x_map = clicked_map.x()
            self.ref_origin_map = clicked_map
            self.line_layer = None
            self.line_geom = None
            self.line_crs = None
            self.segment_angle = 0.0
            return

        fid = match.featureId()
        feat = next(layer.getFeatures(QgsFeatureRequest(fid)), None)
        if feat is None or feat.geometry() is None or feat.geometry().isEmpty():
            self.virtual_x_map = clicked_map.x()
            self.ref_origin_map = clicked_map
            self.line_layer = None
            self.line_geom = None
            self.line_crs = None
            self.segment_angle = 0.0
            return

        self.ref_origin_map = QgsPointXY(match.point())
        self.line_layer = layer
        self.line_crs = layer.crs()
        self.virtual_x_map = None

        geom = feat.geometry()
        if QgsWkbTypes.geometryType(geom.wkbType()) == QgsWkbTypes.PolygonGeometry:
            geom = geom.boundary()

        self.line_geom = geom

        # Compute direction angle in MAP CRS
        ctx = QgsProject.instance().transformContext()
        to_layer = QgsCoordinateTransform(self.map_crs, self.line_crs, ctx)
        to_map_from_layer = QgsCoordinateTransform(self.line_crs, self.map_crs, ctx)

        if hasattr(match, "hasEdge") and match.hasEdge():
            a_map, b_map = match.edgePoints()
            self.segment_angle = self.calculate_azimuth(QgsPointXY(a_map), QgsPointXY(b_map))
            return


        # Fallback: derive closest segment from geometry
        clicked_layer = to_layer.transform(clicked_map)
        dist, min_pt_layer, after_vertex, left_of = self.line_geom.closestSegmentWithContext(clicked_layer)

        verts = [QgsPointXY(v) for v in self.line_geom.vertices()]
        if after_vertex is None or after_vertex < 1 or after_vertex >= len(verts):
            self.virtual_x_map = clicked_map.x()
            self.ref_origin_map = clicked_map
            self.line_layer = None
            self.line_geom = None
            self.line_crs = None
            self.segment_angle = 0.0
            return

        a_map = to_map_from_layer.transform(verts[after_vertex - 1])
        b_map = to_map_from_layer.transform(verts[after_vertex])
        self.segment_angle = self.calculate_azimuth(a_map, b_map)


    def _midpoint_and_side_from_map_point(self, map_point: QgsPointXY):
        if self.segment_angle is not None and self.ref_origin_map is not None:
            ux = math.sin(self.segment_angle)
            uy = math.cos(self.segment_angle)

            dx = map_point.x() - self.ref_origin_map.x()
            dy = map_point.y() - self.ref_origin_map.y()

            # scalar projection onto direction u
            t = dx * ux + dy * uy

            mid_map = QgsPointXY(
                self.ref_origin_map.x() + t * ux,
                self.ref_origin_map.y() + t * uy
            )
        else:
            # Fallback: virtual vertical line in MAP CRS
            if self.virtual_x_map is None:
                self.virtual_x_map = map_point.x()
            mid_map = QgsPointXY(self.virtual_x_map, map_point.y())

        side_sign = self._compute_side_sign(mid_map, self.segment_angle, map_point)
        return mid_map, side_sign


    def _compute_side_sign(self, mid_map: QgsPointXY, angle_rad: float, p_map: QgsPointXY):
        vx = math.sin(angle_rad)
        vy = math.cos(angle_rad)

        sx = p_map.x() - mid_map.x()
        sy = p_map.y() - mid_map.y()

        cross = vx * sy - vy * sx

        eps = 0.25  # metres in MAP CRS (UTM)
        if abs(cross) <= eps:
            return None

        return -1 if cross > 0 else +1


    def update_rubber_band(self, mid_map, angle_rad, side_sign):
        total_width = self.n * self.width

        ux = math.sin(angle_rad)
        uy = math.cos(angle_rad)

        vx = math.cos(angle_rad) * side_sign
        vy = -math.sin(angle_rad) * side_sign

        half_L = self.length / 2.0

        e1 = QgsPointXY(mid_map.x() - half_L * ux, mid_map.y() - half_L * uy)
        e2 = QgsPointXY(mid_map.x() + half_L * ux, mid_map.y() + half_L * uy)

        # First strip needs to be centered on the AB line
        start_off = -self.width / 2.0
        end_off = total_width - self.width / 2.0

        e1_start = QgsPointXY(e1.x() + start_off * vx, e1.y() + start_off * vy)
        e2_start = QgsPointXY(e2.x() + start_off * vx, e2.y() + start_off * vy)

        e1_end = QgsPointXY(e1.x() + end_off * vx, e1.y() + end_off * vy)
        e2_end = QgsPointXY(e2.x() + end_off * vx, e2.y() + end_off * vy)

        geom = QgsGeometry.fromPolygonXY([[e1_start, e2_start, e2_end, e1_end, e1_start]])
        self.rubber_band.setToGeometry(geom, None)



    def create_features(self, mid_map, angle_rad, side_sign):
        layer = QgsVectorLayer(
            f"Polygon?crs={self.out_crs.authid()}",
            "Trial Strips",
            "memory"
        )
        pr = layer.dataProvider()
        pr.addAttributes([QgsField("strip_id", QVariant.Int)])
        layer.updateFields()

        ux = math.sin(angle_rad)
        uy = math.cos(angle_rad)

        vx = math.cos(angle_rad) * side_sign
        vy = -math.sin(angle_rad) * side_sign

        half_L = self.length / 2.0
        base1 = QgsPointXY(mid_map.x() - half_L * ux, mid_map.y() - half_L * uy)
        base2 = QgsPointXY(mid_map.x() + half_L * ux, mid_map.y() + half_L * uy)

        features = []
        offset_start = -self.width / 2.0

        for i in range(self.n):
            o0 = offset_start + i * self.width
            o1 = offset_start + (i + 1) * self.width

            # Build in MAP CRS (UTM metres)
            p1 = QgsPointXY(base1.x() + o0 * vx, base1.y() + o0 * vy)
            p2 = QgsPointXY(base2.x() + o0 * vx, base2.y() + o0 * vy)
            p3 = QgsPointXY(base2.x() + o1 * vx, base2.y() + o1 * vy)
            p4 = QgsPointXY(base1.x() + o1 * vx, base1.y() + o1 * vy)

            geom = QgsGeometry.fromPolygonXY([[p1, p2, p3, p4, p1]])
            geom.transform(self._map_to_out)

            feat = QgsFeature()
            feat.setGeometry(geom)
            feat.setAttributes([i + 1])
            features.append(feat)

        pr.addFeatures(features)
        layer.updateExtents()
        QgsProject.instance().addMapLayer(layer)

        self.iface.messageBar().pushMessage(
            "Success",
            f"Created {self.n} strips.",
            level=Qgis.Success,
            duration=4
        )


class OnFarmExperimentPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.tool = None


    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")

        if os.path.exists(icon_path):
            icon = QIcon(icon_path)
        else:
            icon = QIcon()

        # Fall back to text icon
        self.action = QAction(
            icon,
            "Create Experiment Strips", self.iface.mainWindow()
        )
        self.action.triggered.connect(self.run)

        # Add to plugins toolbar
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&On-farm Experiments", self.action)


    def unload(self):
        if self.tool and self.iface.mapCanvas().mapTool() is self.tool:
            self.iface.mapCanvas().unsetMapTool(self.tool)


        self.tool = None

        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginMenu("&On-farm Experiments", self.action)
        del self.action


    def run(self):
        dlg = TrialConfigDialog(self.iface, self.iface.mainWindow())
        if dlg.exec():
            n, w, l, out_crs = dlg.get_params()

            self.tool = PaddockPlacementTool(self.iface, n, w, l, out_crs)
            self.iface.mapCanvas().setMapTool(self.tool)
            self.iface.messageBar().pushMessage(
                "Tool Active",
                "Click an AB line, and then click again to set the direction. Cancel using right click or escape.",
                level=Qgis.Info
            )
