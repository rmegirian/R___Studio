def classFactory(iface):
    from .ofe_creator import OnFarmExperimentPlugin
    return OnFarmExperimentPlugin(iface)
